#!/usr/bin/python

import re
from argparse import ArgumentParser as ap

parser = ap(description='Converts pokered music disassembly format files to pokecrystal music disassembly format (current version)')
parser.add_argument('file', metavar='FILE')
parser.add_argument('out', metavar='OUTPUT')

args = parser.parse_args()

out_file = open(args.out, "w")

with open(args.file, "r") as red:
    entire_file = red.read()

    tracks = re.findall(r'([A-Za-z0-9_]+)_Ch[1-4]:', entire_file)

    # write header
    channel_num = len(tracks)
    song_name = tracks[0]

    out_file.write(song_name + ':'+'\n')

    max_channel_num = channel_num

    out_file.write('\tchannel_count ' + str(max_channel_num) +'\n')

    while channel_num != 0:
        channel_string = '\tchannel '
        cur_channel_num = max_channel_num-channel_num+1
        channel_string += str(cur_channel_num)
        channel_string += ', '
        channel_string += song_name
        channel_string += '_Ch'
        channel_string += str(cur_channel_num)
        channel_num -= 1
        out_file.write(channel_string+'\n')

    # add the togglenoise command to ch4, falling back to 5
    entire_file = re.sub(r'([A-Za-z0-9_]+)_Ch4:', r'\1_Ch4:\n\ttoggle_noise 5', entire_file)

    # write the rest of the file (after adding togglenoise)
    out_file.write(entire_file)

